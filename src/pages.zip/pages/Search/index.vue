<template>
  <div>
    Search
    <br />
    <!-- params参数 ： {{ $route.params.keyword_p }} -->
    params参数 ： {{ keyword_p }}
    <br />
    <!-- query参数 ： {{ $route.query.keyword_q }} -->
    query参数 ： {{ keyword_q }}
  </div>
</template>

<script>
export default {
  name: "Search",
  data() {
    return {};
  },
  props: ["keyword_q", "keyword_p"],
};
</script>

<style scoped lang="less"></style>
