<template>
  <div>Login</div>
</template>

<script>
export default {
  name: "Login",
  data() {
    return {};
  },
};
</script>

<style scoped lang="less"></style>
