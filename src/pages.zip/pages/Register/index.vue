<template>
  <div>Register</div>
</template>

<script>
export default {
  name: "Register",
  data() {
    return {};
  },
};
</script>

<style scoped lang="less"></style>
